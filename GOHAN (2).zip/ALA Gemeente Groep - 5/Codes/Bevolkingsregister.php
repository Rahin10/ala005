<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Page Title</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
    </head>

        <body>
            <div id="logo"><a href="Index.php"><img src="../Images/Logo.jpg"></a>
            </div>    

            <!-- Navbar -->
            <nav>
                <ul>
                    <li><a class="bline" href="Index.php">Home</a></li>
                    <li><a class="bline" href="Afspraak.php">Afspraak maken</a></li>
                    <li><a class="bline" href="Informatie.php">Informatie opvragen</a></li>
                    <li><a class="bline" href="Toerisme.php">Toerisme</a></li>
                </ul>
            <nav>             
            <!-- Navbar END -->

            <div id="page-head">
                <h2>Bevolkingsregister inzien</h2>
            </div>

                <div class="box">
                    <div id="tekst">
                        <p>
                            <h3>Waar kan ik een afschrift of uittreksel van de burgerlijke stand aanvragen?</h3>
                            De burgerlijke stand maakt akten op van belangrijke gebeurtenissen in uw leven,<br>
                            zoals: geboorte, huwelijk, echtscheiding, geregistreerd partnerschap, beëindiging<br>
                            geregistreerd partnerschap en overlijden.
                            <br>
                            <h3>Uittreksel burgerlijke stand</h3>
                            Een uittreksel bevat alleen de persoonsgegevens uit de akte. De volgende personen kunnen een<br>
                            uittreksel aanvragen:<br>
                            <br>
                                •uzelf;<br>
                                •een gemachtigde;<br>
                                •andere belanghebbende (echtgenoot of erfgenaam).<br>
                            <br>
                            Om een uittreksel aan te vragen, heeft u een geldig legitimatiebewijs nodig.<br>
                            U kunt een uittreksel uit de burgerlijke stand aanvragen bij de gemeente waar de akte is opgemaakt.<br>
                            Dat geldt ook als u daarna bent verhuisd of geëmigreerd.<br>
                            <br>
                            Wilt u een Bevolkingsregister inzien, vul dan <a href="Afspraak.php">hier</a> het formulier in.
                        </p>
                    </div>
                </div>

            <!-- Footer -->
            <footer class="footer">
                <!-- Footer Div 1 -->
                <div>
                    <p>
                        <h2>Stadhuis</h2>
                        Stadhuisplein 1
                        2711 EC Zoetermeer
                    </p>
                </div><!-- Footer Div 1 END -->

                <!-- Footer Div 2 -->
                <div id="direct">
                        <h2>Direct naar</h2>
                            <li><a href="Informatie.php">Informatie</a></li>
                            <li><a href="Afspraak.php">Afspraak maken</a></li>
                            <li><a href="Toerisme.php">Toerisme</a></li>
                </div><!-- Footer Div 2 END -->


                <!-- Footer Div 3 -->
                <div id="social"><h2>Volg ons</h2>
                    <a href="https://twitter.com/gemzoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150167&amp;f=fb087faba1ddf9f453b976ac67041d8ba656c548f0b1c62f81e69f8f7583da3535246bb0d3b7c07e0a629dca5379ff7b03094f96214266f1a291714892ac19b3"></a>
                    <a href="https://nl-nl.facebook.com/gemeentezoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150179&amp;f=58e46348d27320c64adbd2a2c6dba20efba8749f736f638c4aa61d6a73e06dfcaddef0919f54401844538acad30343d9d53400025d313458d85c9ea30c1d997c"></a>

            </footer><!-- Footer END -->

        </body>
</html>
