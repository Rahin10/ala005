<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Gemeente Zoetermeer - Informatie opvragen</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
    </head>

        <body id="info">
            <div id="logo"><a href="Index.php"><img src="../Images/Logo.jpg"></a>
            </div>
                        
                    <!-- Navbar -->
                    <nav>
                        <ul>
                            <li><a class="bline" href="Index.php">Home</a></li>
                            <li><a class="bline" href="Afspraak.php">Afspraak maken</a></li>
                            <li><a class="bline" href="Informatie.php">Informatie opvragen</a></li>
                            <li><a class="bline" href="Toerisme.php">Toerisme</a></li>
                        </ul>
                    </nav>              
                    <!-- Navbar END -->

            <div class="container">
                
                <div id="divbg">
                    <div id="div1">
                        <p>Informatie opvragen</p>
                    </div>
                </div>

                <div id="div2">
                    <h3>Paspoort</h3>
                        <div class="imgp">
                            <img src="../Images/paspoort.png" width="170" height="240">
                        </div>
                    <a class="Binfo"href="paspoort.php">klik hier</a>
                </div>
                
                <div id="div3">
                    <h3>Kapvergunning</h3>
                        <div class="imgk">
                            <img src="../Images/kap.png" width="170" height="220">
                        </div>
                    <a class="Binfo"href="Kapvergunning.php">klik hier</a>
                </div>

                <div id="div4">
                    <h3>Bevolkingsregister</h3>
                        <div class="imgb">
                            <img src="../Images/register.png" width="200" height="220">
                        </div>
                   <a class="Binfo"href="Bevolkingsregister.php">klik hier</a>
                </div>
            </div>


            <!-- Footer -->
            <footer class="footer">
                <!-- Footer Div 1 -->
                <div>
                    <p>
                        <h2>Stadhuis</h2>
                        Stadhuisplein 1
                        2711 EC Zoetermeer
                    </p>
                </div><!-- Footer Div 1 END -->

                <!-- Footer Div 2 -->
                <div id="direct">
                        <h2>Direct naar</h2>
                            <li><a href="Informatie.php">Informatie</a></li>
                            <li><a href="Afspraak.php">Afspraak maken</a></li>
                            <li><a href="Toerisme.php">Toerisme</a></li>
                </div><!-- Footer Div 2 END -->


                <!-- Footer Div 3 -->
                <div id="social"><h2>Volg ons</h2>
                    <a href="https://twitter.com/gemzoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150167&amp;f=fb087faba1ddf9f453b976ac67041d8ba656c548f0b1c62f81e69f8f7583da3535246bb0d3b7c07e0a629dca5379ff7b03094f96214266f1a291714892ac19b3"></a>
                    <a href="https://nl-nl.facebook.com/gemeentezoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150179&amp;f=58e46348d27320c64adbd2a2c6dba20efba8749f736f638c4aa61d6a73e06dfcaddef0919f54401844538acad30343d9d53400025d313458d85c9ea30c1d997c"></a>

            </footer><!-- Footer END -->

        </body>

</html>