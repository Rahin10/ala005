<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Gemeente Zoetermeer - Toerisme</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
    </head>

        <body id="Toerisme">
            <div id="logo"><a href="Index.php"><img src="../Images/Logo.jpg"></a>
            </div>
                
            <!-- Navbar -->
            <nav>
                <ul>
                    <li><a class="bline" href="Index.php">Home</a></li>
                    <li><a class="bline" href="Afspraak.php">Afspraak maken</a></li>
                    <li><a class="bline" href="Informatie.php">Informatie opvragen</a></li>
                    <li><a class="bline" href="Toerisme.php">Toerisme</a></li>
                </ul>
            </nav>              
            <!-- Navbar END -->

            <div>
                <button id="modal-trigger">NL - EN</button>
            </div>

            <!-- main content -->
            <div id="main-content">

                <!-- vak 1 -->
                <div class="grid" id="vakje1">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>Ayers Rock</h4>
                            <p>Het activiteiten centrum voor uitdagende indoor- en outdoor activiteiten...</p>
                        </div>
                            <div class="knop">
                                <a href="https://ayersrock.nl/" target="_blank"><button class="button">klik hier</button></a>
                            </div>
                </div>

    	        <!-- vak 2 -->
                <div class="grid" id="vakje2">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>Zoetermeerse Plas</h4>
                            <p>Recreatie mogelijkheden zijn: varen, zwemmen wandelen en veel meer...</p>
                        </div>
                            <div class="knop">
                                <a href="https://www.zoetermeer.nl/vrije-tijd/recreatie_46892" target="_blank"><button class="button">klik hier</button></a>
                            </div>    
                </div>

                <!-- vak 3 -->
                <div class="grid" id="vakje3">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>SnowWorld</h4>
                            <p>De leukste actieve bedrijfsuitjes boek je bij SnowWorld Zoetermeer...</p>
                        </div>
                            <div class="knop">
                                <a href="https://www.snowworld.com/zoetermeer/nl" target="_blank"><button class="button">klik hier</button></a>
                            </div>    
                </div>

                <!-- vak 4 -->
                <div class="grid" id="vakje4">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>Hommerson Casino's</h4>
                            <p>Spectaculair casino, dobbel mee voor cash in Zoetermeer...</p>
                        </div>
                            <div class="knop">
                                <a href="https://www.hommerson.nl/filialen/zoetermeer" target="_blank"><button class="button">klik hier</button></a>
                            </div>       
                </div>
                
                <!-- vak 5 -->
                <div class="grid" id="vakje5">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>Escaperoom Wescape</h4>
                            <p>Beleef het avontuur bij Wescape de escape room van Zoetermeer...</p>
                        </div>
                            <div class="knop">
                                <a href="https://wescape.nl/" target="_blank"><button class="button">klik hier</button></a>
                            </div>
                </div>

                <!-- vak 6 -->
                <div class="grid" id="vakje6">
                    <div class="image">
                    </div>
                        <div class="tekst">
                            <h4>Kasteel Duivenvoorde</h4>
                            <p>Het museumseizoen 2019 wordt zondag 14 april feestelijk geopend...</p>
                        </div>
                            <div class="knop">
                                <a href="https://www.kasteelduivenvoorde.nl/" target="_blank"><button class="button">klik hier</button></a>
                            </div>   
                </div>
            </div>            

            <!-- Footer -->
            <footer class="footer">
                <!-- Footer Div 1 -->
                <div>
                    <p>
                        <h2>Stadhuis</h2>
                        Stadhuisplein 1
                        2711 EC Zoetermeer
                    </p>
                </div><!-- Footer Div 1 END -->

                <!-- Footer Div 2 -->
                <div id="direct">
                        <h2>Direct naar</h2>
                            <li><a href="Informatie.php">Informatie</a></li>
                            <li><a href="Afspraak.php">Afspraak maken</a></li>
                            <li><a href="Toerisme.php">Toerisme</a></li>
                </div><!-- Footer Div 2 END -->


                <!-- Footer Div 3 -->
                <div id="social"><h2>Volg ons</h2>
                    <a href="https://twitter.com/gemzoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150167&amp;f=fb087faba1ddf9f453b976ac67041d8ba656c548f0b1c62f81e69f8f7583da3535246bb0d3b7c07e0a629dca5379ff7b03094f96214266f1a291714892ac19b3"></a>
                    <a href="https://nl-nl.facebook.com/gemeentezoetermeer"> <img src="https://www.zoetermeer.nl/plaat.php?fileid=150179&amp;f=58e46348d27320c64adbd2a2c6dba20efba8749f736f638c4aa61d6a73e06dfcaddef0919f54401844538acad30343d9d53400025d313458d85c9ea30c1d997c"></a>

            </footer><!-- Footer END -->
                <script src="script.js"></script>
        </body>
</html>
